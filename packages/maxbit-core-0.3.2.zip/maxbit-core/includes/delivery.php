<?php
defined( 'ABSPATH' ) || exit;

/**
 * Адаптер доставки обращения во внешнюю систему.
 * ВЫКЛЮЧЕН по умолчанию: MAXBIT_B24_WEBHOOK_URL пуст и режим LOCAL_TEST.
 * Контракты подтверждения:
 *  - протокол 'test' (локальный приёмник): HTTP 2xx, JSON, ok === true, received === request_id;
 *  - протокол 'bitrix24' (crm.lead.add и т.п.): HTTP 2xx, JSON без ключа error, result — положительное целое
 *    либо непустой массив с положительным ID. Карта полей/метод — отдельная задача выпуска (см. OPEN_ITEMS).
 * Всё остальное — не доставка. delivered — терминальный статус: повторы не выполняют сетевых вызовов
 * и не меняют его. Обработка каждой заявки — под блокировкой; ожидающие повторы после успеха снимаются.
 */

const MAXBIT_DELIVERY_TIMEOUT      = 5;
const MAXBIT_DELIVERY_MAX_ATTEMPTS = 3;

function maxbit_delivery_enabled(): bool {
	return (bool) MAXBIT_B24_WEBHOOK_URL && 'LOCAL_TEST' !== MAXBIT_FORM_MODE;
}

/** Тестовый приёмник можно задать даже в LOCAL_TEST (MAXBIT_DELIVERY_TEST_URL), протокол при этом — 'test'. */
function maxbit_delivery_url(): string {
	if ( defined( 'MAXBIT_DELIVERY_TEST_URL' ) && MAXBIT_DELIVERY_TEST_URL ) {
		return MAXBIT_DELIVERY_TEST_URL;
	}
	return maxbit_delivery_enabled() ? MAXBIT_B24_WEBHOOK_URL : '';
}

function maxbit_delivery_protocol(): string {
	if ( defined( 'MAXBIT_DELIVERY_TEST_URL' ) && MAXBIT_DELIVERY_TEST_URL ) {
		return 'test';
	}
	return defined( 'MAXBIT_DELIVERY_PROTOCOL' ) ? MAXBIT_DELIVERY_PROTOCOL : 'bitrix24';
}

add_action( 'maxbit_lead_stored', function ( int $post_id ) {
	if ( ! maxbit_delivery_url() ) {
		return; // выключено — статус 'disabled'
	}
	maxbit_deliver_lead( $post_id );
} );

/** Строгая проверка ответа получателя. Возвращает '' при подтверждении, иначе код причины. */
function maxbit_delivery_confirm( int $code, string $body, string $request_id, string $protocol ): string {
	if ( $code < 200 || $code >= 300 ) {
		return 'http_' . $code;
	}
	$json = json_decode( $body, true );
	if ( ! is_array( $json ) ) {
		return 'bad_json';
	}
	if ( 'test' === $protocol ) {
		if ( ( $json['ok'] ?? null ) !== true ) {
			return 'not_confirmed';
		}
		if ( ( $json['received'] ?? null ) !== $request_id ) {
			return 'request_id_mismatch';
		}
		return '';
	}
	// bitrix24
	if ( isset( $json['error'] ) || ! array_key_exists( 'result', $json ) ) {
		return 'not_confirmed';
	}
	$r = $json['result'];
	if ( is_int( $r ) && $r > 0 ) {
		return '';
	}
	if ( is_string( $r ) && ctype_digit( $r ) && (int) $r > 0 ) {
		return '';
	}
	if ( is_array( $r ) && ! empty( $r ) && isset( $r['ID'] ) && (int) $r['ID'] > 0 ) {
		return '';
	}
	return 'not_confirmed';
}

/**
 * Одна попытка доставки под блокировкой. true — подтверждённый успех (в т.ч. уже достигнутый ранее).
 */
function maxbit_deliver_lead( int $post_id ): bool {
	$post = get_post( $post_id );
	if ( ! $post || 'mb_lead' !== $post->post_type || 'private' !== $post->post_status ) {
		return false;
	}
	if ( 'delivered' === get_post_meta( $post_id, '_mb_delivery_status', true ) ) {
		return true; // терминальный статус: без сетевого вызова и без изменения
	}
	$url = maxbit_delivery_url();
	if ( ! $url ) {
		return false;
	}
	if ( ! maxbit_lock_acquire( 'deliver_' . $post_id, MAXBIT_DELIVERY_TIMEOUT + 10 ) ) {
		return false; // уже обрабатывается параллельно
	}
	try {
		wp_cache_delete( $post_id, 'post_meta' );
		if ( 'delivered' === get_post_meta( $post_id, '_mb_delivery_status', true ) ) {
			return true;
		}
		$attempts = (int) get_post_meta( $post_id, '_mb_delivery_attempts', true );
		if ( $attempts >= MAXBIT_DELIVERY_MAX_ATTEMPTS ) {
			update_post_meta( $post_id, '_mb_delivery_status', 'failed' );
			return false;
		}
		update_post_meta( $post_id, '_mb_delivery_attempts', $attempts + 1 );
		update_post_meta( $post_id, '_mb_delivery_status', 'pending' );

		$request_id = get_post_meta( $post_id, '_mb_request_id', true );
		$payload = array(
			'request_id' => $request_id,
			'topic'      => get_post_meta( $post_id, '_mb_topic', true ),
			'name'       => get_post_meta( $post_id, '_mb_name', true ),
			'contact'    => get_post_meta( $post_id, '_mb_contact', true ),
			'message'    => get_post_meta( $post_id, '_mb_message', true ),
			'source'     => get_post_meta( $post_id, '_mb_source', true ),
			'mode'       => MAXBIT_FORM_MODE,
			'attempt'    => $attempts + 1,
		);
		$resp = wp_remote_post( $url, array(
			'timeout' => MAXBIT_DELIVERY_TIMEOUT,
			'headers' => array( 'Content-Type' => 'application/json', 'X-Request-Id' => $request_id ),
			'body'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE ),
		) );
		if ( is_wp_error( $resp ) ) {
			return maxbit_delivery_failed( $post_id, $resp->get_error_code() );
		}
		$why = maxbit_delivery_confirm( (int) wp_remote_retrieve_response_code( $resp ), (string) wp_remote_retrieve_body( $resp ), (string) $request_id, maxbit_delivery_protocol() );
		if ( '' !== $why ) {
			return maxbit_delivery_failed( $post_id, $why );
		}
		update_post_meta( $post_id, '_mb_delivery_status', 'delivered' );
		update_post_meta( $post_id, '_mb_delivery_last_error', '' );
		update_post_meta( $post_id, '_mb_delivered_at', gmdate( 'c' ) );
		wp_clear_scheduled_hook( 'maxbit_delivery_retry', array( $post_id ) ); // оставшиеся повторы снимаем
		do_action( 'maxbit_lead_delivered', $post_id, $request_id );
		return true;
	} finally {
		maxbit_lock_release( 'deliver_' . $post_id );
	}
}

function maxbit_delivery_failed( int $post_id, string $reason ): bool {
	update_post_meta( $post_id, '_mb_delivery_last_error', sanitize_key( $reason ) );
	$attempts = (int) get_post_meta( $post_id, '_mb_delivery_attempts', true );
	if ( $attempts >= MAXBIT_DELIVERY_MAX_ATTEMPTS ) {
		update_post_meta( $post_id, '_mb_delivery_status', 'failed' );
		wp_clear_scheduled_hook( 'maxbit_delivery_retry', array( $post_id ) );
	} else {
		update_post_meta( $post_id, '_mb_delivery_status', 'retry' );
		wp_clear_scheduled_hook( 'maxbit_delivery_retry', array( $post_id ) ); // одна задача повтора на заявку
		wp_schedule_single_event( time() + 60 * $attempts, 'maxbit_delivery_retry', array( $post_id ) );
	}
	return false;
}
add_action( 'maxbit_delivery_retry', 'maxbit_deliver_lead' );
