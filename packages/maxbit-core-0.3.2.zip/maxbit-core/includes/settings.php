<?php
defined( 'ABSPATH' ) || exit;

function maxbit_get_settings(): array {
	$defaults = array(
		'phone'      => '',
		'email'      => '',
		'messenger'  => '',
		'messenger_url' => '',
		'founder'    => 'Максим Кизимов',
	);
	$saved = get_option( 'maxbit_settings', array() );
	return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
}

add_action( 'admin_menu', function () {
	add_menu_page( 'MAXBIT', 'MAXBIT', 'manage_options', 'maxbit', 'maxbit_settings_page', 'dashicons-admin-site-alt3', 3 );
} );

add_action( 'admin_init', function () {
	register_setting( 'maxbit_env', 'maxbit_env', array(
		'type' => 'string',
		'sanitize_callback' => fn( $v ) => in_array( $v, array( 'local', 'staging' ), true ) ? $v : 'staging',
	) );
	register_setting( 'maxbit_env', 'maxbit_disable_mail', array(
		'type' => 'string',
		'sanitize_callback' => fn( $v ) => '1' === (string) $v ? '1' : '0',
	) );
	register_setting( 'maxbit', 'maxbit_settings', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : array();
			return array(
				'phone'         => mb_substr( sanitize_text_field( $in['phone'] ?? '' ), 0, 40 ),
				'email'         => sanitize_email( $in['email'] ?? '' ),
				'messenger'     => mb_substr( sanitize_text_field( $in['messenger'] ?? '' ), 0, 60 ),
				'messenger_url' => esc_url_raw( $in['messenger_url'] ?? '' ),
				'founder'       => mb_substr( sanitize_text_field( $in['founder'] ?? '' ), 0, 80 ),
			);
		},
	) );
} );

function maxbit_settings_page(): void {
	$s = maxbit_get_settings();
	$missing = array();
	foreach ( array( 'phone' => 'телефон', 'email' => 'почта' ) as $k => $label ) {
		if ( empty( $s[ $k ] ) ) {
			$missing[] = $label;
		}
	}
	?>
	<div class="wrap">
		<h1>MAXBIT — состояние сайта</h1>
		<table class="widefat striped" style="max-width:800px;margin:1em 0">
			<tbody>
			<tr><th>Среда</th><td><code><?php echo esc_html( MAXBIT_ENV ); ?></code> — <?php echo 'production' === MAXBIT_ENV ? 'рабочая' : 'не индексируется, черновики закрыты, внешние отправки выключены'; ?></td></tr>
			<tr><th>Режим формы</th><td><code><?php echo esc_html( MAXBIT_FORM_MODE ); ?></code> — обращения сохраняются локально как тестовые и не отправляются MAXBIT</td></tr>
			<tr><th>Доставка в Битрикс24</th><td><?php echo MAXBIT_B24_WEBHOOK_URL ? 'адрес задан (адаптер активен)' : '<strong>выключена</strong> — адрес вебхука не задан'; ?></td></tr>
			<tr><th>Аналитика</th><td><?php echo MAXBIT_ANALYTICS_ENABLED ? 'включена' : '<strong>выключена</strong> — события только в dataLayer/консоль'; ?></td></tr>
			<tr><th>Почта WordPress</th><td><?php echo ( 'production' !== MAXBIT_ENV && '1' === (string) get_option( 'maxbit_disable_mail', '1' ) ) ? '<strong>выключена</strong> (стенд): письма, включая сброс пароля, не отправляются' : 'включена'; ?></td></tr>
			<tr><th>Индексирование</th><td><?php echo ( 'production' === MAXBIT_ENV && '1' === (string) get_option( 'blog_public' ) ) ? 'разрешено' : '<strong>запрещено</strong> (noindex для всех страниц, robots: Disallow /, sitemap выключен)'; ?>; «Настройки → Чтение → Попросить поисковые системы не индексировать»: <?php echo '1' === (string) get_option( 'blog_public' ) ? 'снята' : 'установлена'; ?></td></tr>
			<tr><th>Пермалинки</th><td><code><?php echo esc_html( get_option( 'permalink_structure' ) ?: '(простые — адреса /praktika/… работать не будут)' ); ?></code></td></tr>
			<tr><th>Тема</th><td><?php echo esc_html( wp_get_theme()->get( 'Name' ) . ' ' . wp_get_theme()->get( 'Version' ) ); ?>; модуль <?php echo esc_html( MAXBIT_CORE_VERSION ); ?></td></tr>
			<tr><th>Содержание</th><td><?php $cnt = wp_count_posts( 'mb_solution' ); echo (int) ( $cnt->publish + $cnt->draft ) . ' решений, ' . (int) wp_count_posts( 'page' )->publish . ' страниц, ' . (int) wp_count_posts( 'mb_lead' )->private . ' обращений'; echo get_option( 'maxbit_seed_done' ) ? '; наполнение выполнено ' . esc_html( get_option( 'maxbit_seed_done' ) ) : '; <strong>наполнение не выполнялось</strong> (MAXBIT → Наполнение)'; ?></td></tr>
			<tr><th>Обязательно до выпуска</th><td>
				<?php if ( $missing ) : ?><span style="color:#b91c1c">Не заполнено: <?php echo esc_html( implode( ', ', $missing ) ); ?>.</span><?php else : ?>Контакты заполнены.<?php endif; ?>
				Незаданные контакты на сайте скрыты; вымышленные не подставляются.
			</td></tr>
			</tbody>
		</table>
		<?php if ( ! ( defined( 'MAXBIT_ENV_FROM_CONFIG' ) ) ) : ?>
		<form method="post" action="options.php" style="margin-bottom:2em">
			<?php settings_fields( 'maxbit_env' ); ?>
			<h2>Среда стенда</h2>
			<p class="description">Константа <code>MAXBIT_ENV</code> в wp-config.php имеет приоритет над этой настройкой. Значение <code>production</code> задаётся только константой — после приёмки, отдельным решением.</p>
			<table class="form-table">
				<tr><th>Среда</th><td>
					<label><input type="radio" name="maxbit_env" value="staging" <?php checked( get_option( 'maxbit_env', 'staging' ), 'staging' ); ?>> staging — тестовый стенд (dev.maxbitpro.ru)</label><br>
					<label><input type="radio" name="maxbit_env" value="local" <?php checked( get_option( 'maxbit_env', 'staging' ), 'local' ); ?>> local — локальная разработка</label>
				</td></tr>
				<tr><th>Почта</th><td><label><input type="checkbox" name="maxbit_disable_mail" value="1" <?php checked( get_option( 'maxbit_disable_mail', '1' ), '1' ); ?>> Не отправлять письма вне production (сброс пароля, уведомления)</label></td></tr>
			</table>
			<?php submit_button( 'Сохранить среду' ); ?>
		</form>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'maxbit' ); ?>
			<h2>Контакты (публичные, показываются только если заполнены)</h2>
			<table class="form-table">
				<tr><th><label for="mb_phone">Телефон</label></th><td><input id="mb_phone" name="maxbit_settings[phone]" type="text" class="regular-text" value="<?php echo esc_attr( $s['phone'] ); ?>"></td></tr>
				<tr><th><label for="mb_email">Почта</label></th><td><input id="mb_email" name="maxbit_settings[email]" type="email" class="regular-text" value="<?php echo esc_attr( $s['email'] ); ?>"></td></tr>
				<tr><th><label for="mb_msg">Мессенджер (подпись)</label></th><td><input id="mb_msg" name="maxbit_settings[messenger]" type="text" class="regular-text" value="<?php echo esc_attr( $s['messenger'] ); ?>" placeholder="например: Telegram"></td></tr>
				<tr><th><label for="mb_msgu">Ссылка мессенджера</label></th><td><input id="mb_msgu" name="maxbit_settings[messenger_url]" type="url" class="regular-text" value="<?php echo esc_attr( $s['messenger_url'] ); ?>"></td></tr>
				<tr><th><label for="mb_founder">Основатель</label></th><td><input id="mb_founder" name="maxbit_settings[founder]" type="text" class="regular-text" value="<?php echo esc_attr( $s['founder'] ); ?>"></td></tr>
			</table>
			<?php submit_button( 'Сохранить' ); ?>
		</form>
	</div>
	<?php
}

/** Контакты на странице «О компании»: только заполненные; иначе — честное сообщение. */
add_shortcode( 'maxbit_contacts', function () {
	$s = maxbit_get_settings();
	$rows = array();
	if ( ! empty( $s['phone'] ) ) {
		$rows[] = '<li><span>Телефон</span><a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $s['phone'] ) ) . '" data-contact="phone">' . esc_html( $s['phone'] ) . '</a></li>';
	}
	if ( ! empty( $s['email'] ) ) {
		$rows[] = '<li><span>Почта</span><a href="mailto:' . esc_attr( $s['email'] ) . '" data-contact="email">' . esc_html( $s['email'] ) . '</a></li>';
	}
	if ( ! empty( $s['messenger_url'] ) ) {
		$rows[] = '<li><span>' . esc_html( $s['messenger'] ?: 'Мессенджер' ) . '</span><a href="' . esc_url( $s['messenger_url'] ) . '" data-contact="messenger" rel="noopener">' . esc_html( $s['messenger_url'] ) . '</a></li>';
	}
	if ( ! $rows ) {
		$note = maxbit_can_preview() ? ' <span class="mb-badge mb-badge--draft">Для редактора: заполните контакты в разделе MAXBIT — до выпуска это обязательно.</span>' : '';
		return '<p>Самый простой способ связаться — форма ниже. Ответим по указанному вами контакту.' . $note . '</p>';
	}
	return '<ul class="mb-contacts">' . implode( '', $rows ) . '</ul>';
} );
