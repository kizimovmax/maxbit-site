<?php
defined( 'ABSPATH' ) || exit;

/**
 * Единственное место SEO-метаданных сайта. Второй SEO-плагин не ставить.
 * Canonical: локально/на стенде — текущий адрес среды; в production — адрес сайта.
 * robots: local/staging → noindex,nofollow для всех; production → по флагу страницы.
 */

function maxbit_site_name(): string {
	return 'MAXBIT';
}

function maxbit_document_title(): string {
	if ( is_singular() ) {
		$id     = get_queried_object_id();
		$custom = get_post_meta( $id, '_mb_seo_title', true );
		if ( $custom ) {
			return $custom;
		}
		if ( is_front_page() ) {
			return 'MAXBIT — внешняя команда цифрового развития производственных компаний';
		}
		return get_the_title( $id ) . ' — MAXBIT';
	}
	$pg = max( 1, (int) get_query_var( 'paged' ) );
	$suffix = $pg > 1 ? ' — страница ' . $pg : '';
	if ( is_home() ) {
		$pp = (int) get_option( 'page_for_posts' );
		$t  = $pp ? (string) get_post_meta( $pp, '_mb_seo_title', true ) : '';
		return ( $t ?: 'Практика: статьи, чек-листы и разборы для руководителя производства — MAXBIT' ) . $suffix;
	}
	if ( is_post_type_archive( 'mb_solution' ) ) {
		return 'Решения для производственных компаний' . $suffix . ' — MAXBIT';
	}
	if ( is_post_type_archive( 'mb_project' ) ) {
		return 'Проекты' . $suffix . ' — MAXBIT';
	}
	if ( is_404() ) {
		return 'Страница не найдена — MAXBIT';
	}
	if ( is_search() ) {
		return 'Поиск — MAXBIT';
	}
	return ''; // пусто = стандартный title ядра (без рекурсии)
}
add_filter( 'pre_get_document_title', 'maxbit_document_title', 20 );

function maxbit_meta_description(): string {
	if ( is_singular() ) {
		$id   = get_queried_object_id();
		$desc = get_post_meta( $id, '_mb_seo_description', true );
		if ( $desc ) {
			return $desc;
		}
		$ex = get_the_excerpt( $id );
		return $ex ? wp_strip_all_tags( $ex ) : '';
	}
	if ( is_home() ) {
		$pp = (int) get_option( 'page_for_posts' );
		$d  = $pp ? (string) get_post_meta( $pp, '_mb_seo_description', true ) : '';
		return $d ?: 'Разборы типовых проблем производственных компаний, чек-листы и инструкции по учёту заказов, Битрикс24 и 1С.';
	}
	if ( is_post_type_archive( 'mb_solution' ) ) {
		return 'Направления MAXBIT для производственных компаний: управление заказами, Битрикс24 для производства, интеграция Битрикс24 и 1С. Состав, границы, порядок работы.';
	}
	return '';
}

function maxbit_canonical_url(): string {
	global $wp;
	$paged = max( 1, (int) get_query_var( 'paged' ) );
	if ( is_singular() ) {
		$url = get_permalink( get_queried_object_id() );
		$page = max( 1, (int) get_query_var( 'page' ) );
		if ( $page > 1 ) {
			$url = trailingslashit( $url ) . $page . '/';
		}
		return $url;
	}
	if ( is_post_type_archive() ) {
		$url = get_post_type_archive_link( get_query_var( 'post_type' ) );
	} elseif ( is_home() ) {
		$url = get_permalink( (int) get_option( 'page_for_posts' ) );
	} else {
		$url = trailingslashit( home_url( $wp->request ) );
	}
	$url = $url ?: home_url( '/' );
	if ( $paged > 1 ) {
		$url = trailingslashit( $url ) . 'page/' . $paged . '/';   // каждая страница пагинации — свой canonical
	}
	return $url;
}
// Отключаем canonical ядра и выводим свой (один на страницу).
remove_action( 'wp_head', 'rel_canonical' );
add_action( 'wp_head', function () {
	if ( is_404() || is_search() ) {
		return;
	}
	$desc = maxbit_meta_description();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<link rel="canonical" href="' . esc_url( maxbit_canonical_url() ) . '">' . "\n";
	echo '<meta property="og:site_name" content="MAXBIT">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( maxbit_document_title() ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:url" content="' . esc_url( maxbit_canonical_url() ) . '">' . "\n";
	echo '<meta property="og:locale" content="ru_RU">' . "\n";
}, 1 );

add_filter( 'wp_robots', function ( array $robots ) {
	// Индексирование только при совокупности: production, blog_public=1, страница публично видима и без noindex.
	// Чужой noindex (ядро, другие правила) никогда не снимаем.
	$blocked = 'production' !== MAXBIT_ENV || '1' !== (string) get_option( 'blog_public' ) || ! empty( $robots['noindex'] );
	$blocked = $blocked || is_404() || is_search() || ( is_post_type_archive( 'mb_project' ) && ! maxbit_has_public_projects() );
	if ( is_singular() ) {
		$id = get_queried_object_id();
		$blocked = $blocked || '1' === get_post_meta( $id, '_mb_noindex', true ) || ! maxbit_is_publicly_visible( $id ) || '1' === get_post_meta( $id, '_mb_is_sample', true );
	}
	if ( $blocked ) {
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
		unset( $robots['index'], $robots['follow'] );
		return $robots;
	}
	$robots['max-image-preview'] = 'large';
	return $robots;
} );

/** robots.txt: политика по средам. Не защита данных — только сигнал роботам. */
add_filter( 'robots_txt', function ( string $output, bool $public ) {
	if ( 'production' !== MAXBIT_ENV || ! $public ) {
		return "User-agent: *\nDisallow: /\n";
	}
	$out  = "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nDisallow: /wp-json/\nDisallow: /?s=\nDisallow: /search/\n";
	$out .= 'Sitemap: ' . home_url( '/wp-sitemap.xml' ) . "\n";
	// Политика для обучающих роботов (GPTBot, CCBot и др.) согласуется отдельно перед выпуском — здесь не задаётся.
	return $out;
}, 10, 2 );

function maxbit_has_public_projects(): bool {
	$q = new WP_Query( array(
		'post_type'      => 'mb_project',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_query'     => array(
			array( 'key' => '_mb_public_ok', 'value' => '1' ),
			array( 'relation' => 'OR', array( 'key' => '_mb_is_sample', 'compare' => 'NOT EXISTS' ), array( 'key' => '_mb_is_sample', 'value' => '1', 'compare' => '!=' ) ),
		),
	) );
	return $q->have_posts();
}

/** Хлебные крошки: массив [label, url]. Домашняя всегда первая. */
function maxbit_breadcrumbs(): array {
	$items = array( array( 'Главная', home_url( '/' ) ) );
	if ( is_front_page() ) {
		return $items;
	}
	if ( is_singular( 'mb_solution' ) ) {
		$items[] = array( 'Решения', get_post_type_archive_link( 'mb_solution' ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'mb_project' ) ) {
		$items[] = array( 'Проекты', get_post_type_archive_link( 'mb_project' ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_singular( 'post' ) ) {
		$items[] = array( 'Практика', get_permalink( (int) get_option( 'page_for_posts' ) ) );
		$items[] = array( get_the_title(), '' );
	} elseif ( is_page() ) {
		$post = get_queried_object();
		if ( $post->post_parent && 'tekhnologii' !== get_post( $post->post_parent )->post_name ) {
			$items[] = array( get_the_title( $post->post_parent ), get_permalink( $post->post_parent ) );
		}
		$items[] = array( get_the_title(), '' );
	} elseif ( is_home() ) {
		$items[] = array( 'Практика', '' );
	} elseif ( is_post_type_archive( 'mb_solution' ) ) {
		$items[] = array( 'Решения', '' );
	} elseif ( is_post_type_archive( 'mb_project' ) ) {
		$items[] = array( 'Проекты', '' );
	} elseif ( is_404() ) {
		$items[] = array( 'Страница не найдена', '' );
	}
	return $items;
}

/** JSON-LD: только достоверное и видимое. Без рейтингов, Offer, SoftwareApplication, адресов офисов. */
add_action( 'wp_head', function () {
	if ( is_404() || is_search() ) {
		return;
	}
	$graph = array();
	$org   = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => 'MAXBIT',
		'url'   => home_url( '/' ),
		'description' => 'Внешняя команда цифрового развития производственных компаний. Ваша команда цифрового развития.',
		'founder' => array( '@type' => 'Person', 'name' => 'Максим Кизимов' ),
		'areaServed' => 'RU',
	);
	$settings = maxbit_get_settings();
	if ( ! empty( $settings['email'] ) ) {
		$org['email'] = $settings['email'];
	}
	if ( ! empty( $settings['phone'] ) ) {
		$org['telephone'] = $settings['phone'];
	}
	$graph[] = $org;
	$graph[] = array(
		'@type' => 'WebSite',
		'@id'   => home_url( '/#website' ),
		'url'   => home_url( '/' ),
		'name'  => 'MAXBIT',
		'publisher' => array( '@id' => home_url( '/#organization' ) ),
		'inLanguage' => 'ru-RU',
	);
	$crumbs = maxbit_breadcrumbs();
	if ( count( $crumbs ) > 1 ) {
		$list = array();
		foreach ( $crumbs as $i => $c ) {
			$item = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0] );
			if ( $c[1] ) {
				$item['item'] = $c[1];
			}
			$list[] = $item;
		}
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );
	}
	if ( is_singular( 'post' ) ) {
		$id = get_queried_object_id();
		$graph[] = array(
			'@type'    => 'Article',
			'headline' => get_the_title( $id ),
			'url'      => get_permalink( $id ),
			'datePublished' => get_the_date( 'c', $id ),
			'dateModified'  => get_the_modified_date( 'c', $id ),
			'author'   => array( '@id' => home_url( '/#organization' ) ),
			'publisher' => array( '@id' => home_url( '/#organization' ) ),
			'inLanguage' => 'ru-RU',
		);
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 5 );

/** Кеш страницы: любое обновление записи сбрасывает кеш объектов и даёт сигнал внешнему кешу (если появится). */
add_action( 'save_post', function ( int $post_id ) {
	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}
	clean_post_cache( $post_id );
	do_action( 'maxbit_purge_url', get_permalink( $post_id ) );
	do_action( 'maxbit_purge_url', home_url( '/' ) );
} );

/** Язык документа — русский (содержание на русском; языковой пакет ядра не обязателен). */
add_filter( 'language_attributes', function ( string $output ) {
	return preg_replace( '/lang="[^"]*"/', 'lang="ru-RU"', $output ) ?: 'lang="ru-RU"';
} );
